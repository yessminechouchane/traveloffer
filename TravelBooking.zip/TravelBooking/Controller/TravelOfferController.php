<?php
require_once 'C:\Users\Lenovo\Desktop\TravelBooking\config.php';

class TravelOfferController
{
    public function listOffers()
    {
        $pdo = Config::getConnexion();
        $query = $pdo->query("SELECT * FROM TravelOffer");
        return $query->fetchAll();
    }


public function deleteOffer($id)
{
    $pdo = Config::getConnexion();
    $stmt = $pdo->prepare("DELETE FROM TravelOffer WHERE id = ?");
    $stmt->execute([$id]);
}


public function addOffer($offer)
{
    $pdo = Config::getConnexion();
    $stmt = $pdo->prepare("INSERT INTO TravelOffer (title, destination, departure_date, return_date, price, disponible, category) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $offer['title'], $offer['destination'], $offer['departure_date'],
        $offer['return_date'], $offer['price'], $offer['disponible'], $offer['category']
    ]);
}
public function updateOffer($id, $offer)
{
    $pdo = Config::getConnexion();
    $stmt = $pdo->prepare("UPDATE TravelOffer SET title = ?, destination = ?, departure_date = ?, return_date = ?, price = ?, disponible = ?, category = ? WHERE id = ?");
    $stmt->execute([
        $offer['title'], $offer['destination'], $offer['departure_date'],
        $offer['return_date'], $offer['price'], $offer['disponible'], $offer['category'], $id
    ]);
}
}

?>
