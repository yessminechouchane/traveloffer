<?php
require_once 'C:\Users\Lenovo\Desktop\TravelBooking\Controller\TravelOfferController.php';

$controller = new TravelOfferController();
$offers = $controller->listOffers();
?>

<h2>Liste des Offres</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Destination</th>
        <th>Departure Date</th>
        <th>Return Date</th>
        <th>Price</th>
        <th>Disponibility</th>
        <th>Category</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($offers as $offer) { ?>
        <tr>
            <td><?= $offer['id'] ?></td>
            <td><?= htmlspecialchars($offer['title']) ?></td>
            <td><?= htmlspecialchars($offer['destination']) ?></td>
            <td><?= $offer['departure_date'] ?></td>
            <td><?= $offer['return_date'] ?></td>
            <td><?= $offer['price'] ?> €</td>
            <td><?= $offer['disponible'] ? 'Available' : 'Not Available' ?></td>
            <td><?= htmlspecialchars($offer['category']) ?></td>
            <td>
                <a href="deleteOffer.php?id=<?= $offer['id'] ?>">Delete</a> |
                <a href="updateOffer.php?id=<?= $offer['id'] ?>">Update</a>
            </td>
        </tr>
    <?php } ?>
</table>
