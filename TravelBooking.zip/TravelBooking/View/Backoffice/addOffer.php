<?php
require_once 'C:\Users\Lenovo\Desktop\TravelBooking\Controller\TravelOfferController.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $offer = [
        'title' => $_POST['title'],
        'destination' => $_POST['destination'],
        'departure_date' => $_POST['departure_date'],
        'return_date' => $_POST['return_date'],
        'price' => $_POST['price'],
        'disponible' => isset($_POST['disponible']) ? 1 : 0,
        'category' => $_POST['category']
    ];

    $controller = new TravelOfferController();
    $controller->addOffer($offer);
    header("Location: listOffers.php");
    exit();
}
?>

<form method="POST">
    <input type="text" name="title" placeholder="Title" required>
    <input type="text" name="destination" placeholder="Destination" required>
    <input type="date" name="departure_date" required>
    <input type="date" name="return_date" required>
    <input type="number" name="price" step="0.01" required>
    <input type="checkbox" name="disponible"> Available
    <input type="text" name="category" placeholder="Category" required>
    <button type="submit">Add Offer</button>
</form>
