<?php
require_once 'C:\Users\Lenovo\Desktop\TravelBooking\Controller\TravelOfferController.php';

if (isset($_GET['id'])) {
    $controller = new TravelOfferController();
    $controller->deleteOffer($_GET['id']);
}

header("Location: listOffers.php");
exit();
?>
