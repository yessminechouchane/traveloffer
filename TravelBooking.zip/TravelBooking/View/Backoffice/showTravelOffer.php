
<?php 
require_once 'C:/Users/Lenovo/Desktop/TravelBooking/Model/TravelOffer.php';

// Création d'une instance avec les setters
$offre1 = new TravelOffer();
$offre1->setTitle('Discover Paris');
$offre1->setDestination('Paris, France');
$offre1->setDepartureDate('2024-10-15');
$offre1->setReturnDate('2024-10-22');
$offre1->setPrice(1200.00);
$offre1->setDisponible(true);
$offre1->setCategory('Cultural');

// Affichage des données avec les getters
echo "Titre : " . $offre1->getTitle() . "<br>";
echo "Destination : " . $offre1->getDestination() . "<br>";
echo "Date de départ : " . $offre1->getDepartureDate() . "<br>";
echo "Date de retour : " . $offre1->getReturnDate() . "<br>";
echo "Prix : " . $offre1->getPrice() . "€<br>";
echo "Disponibilité : " . ($offre1->isDisponible() ? "Disponible" : "Indisponible") . "<br>";
echo "Catégorie : " . $offre1->getCategory() . "<br>";

// Affichage du tableau
$offre1->show();
?> 


