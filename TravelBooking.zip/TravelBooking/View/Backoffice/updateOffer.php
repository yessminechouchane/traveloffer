<?php
require_once 'C:\Users\Lenovo\Desktop\TravelBooking\Controller\TravelOfferController.php';

$controller = new TravelOfferController();

// Vérifier si l'ID est fourni dans l'URL
if (!isset($_GET['id'])) {
    die("ID d'offre manquant.");
}

$id = $_GET['id'];

// Récupérer l'offre existante
$pdo = Config::getConnexion();
$stmt = $pdo->prepare("SELECT * FROM TravelOffer WHERE id = ?");
$stmt->execute([$id]);
$offer = $stmt->fetch();

if (!$offer) {
    die("Offre introuvable.");
}

// Si le formulaire est soumis, on met à jour l'offre
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $updatedOffer = [
        'title' => $_POST['title'],
        'destination' => $_POST['destination'],
        'departure_date' => $_POST['departure_date'],
        'return_date' => $_POST['return_date'],
        'price' => $_POST['price'],
        'disponible' => isset($_POST['disponible']) ? 1 : 0,
        'category' => $_POST['category']
    ];

    $controller->updateOffer($id, $updatedOffer);

    // Redirection vers la liste des offres après modification
    header("Location: listOffers.php");
    exit();
}
?>

<h2>Modifier l'offre</h2>
<form method="POST">
    <input type="text" name="title" value="<?= htmlspecialchars($offer['title']) ?>" required>
    <input type="text" name="destination" value="<?= htmlspecialchars($offer['destination']) ?>" required>
    <input type="date" name="departure_date" value="<?= $offer['departure_date'] ?>" required>
    <input type="date" name="return_date" value="<?= $offer['return_date'] ?>" required>
    <input type="number" name="price" step="0.01" value="<?= $offer['price'] ?>" required>
    <label>
        <input type="checkbox" name="disponible" <?= $offer['disponible'] ? 'checked' : '' ?>> Disponible
    </label>
    <input type="text" name="category" value="<?= htmlspecialchars($offer['category']) ?>" required>
    <button type="submit">Mettre à jour</button>
</form>
